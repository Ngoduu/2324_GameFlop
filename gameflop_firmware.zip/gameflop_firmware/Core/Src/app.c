/*
 * app.c
 *
 *  Created on: Jun 12, 2024
 *      Author: admin
 */

#include "app.h"
#include "cmsis_os.h"
enum
{
	A,
	B,
	Up,
	Left,
	Down,
	Right,
	Select,
	Start
};

extern osMessageQueueId_t Input_QueueHandle;

void Port_IRQ(unsigned char btn)
{
	BaseType_t pxHigherPriorityTaskWoken;
	unsigned char msg;
	switch(btn)
	{
	case A:
		msg = 'A';
			break;
	case B:
		msg = 'B';
			break;
	case Up:
		msg = 'U';
			break;
	case Left:
		msg = 'L';
			break;
	case Down:
		msg = 'D';
			break;
	case Right:
		msg = 'R';
			break;
	case Select:
		msg = '-';
			break;
	case Start:
		msg = '+';
			break;
	default:
		return;
	}
	(void)xQueueSendFromISR(Input_QueueHandle, &msg, &pxHigherPriorityTaskWoken);
	portYIELD_FROM_ISR(pxHigherPriorityTaskWoken);
}

void backend(void* context)
{
	unsigned char input;
	(void)context;
	while(1)
	{
		xQueueReceive(Input_QueueHandle, &input, portMAX_DELAY);

		// Traitement des inputs
	}
}

void GUI_Task(void* context)
{
	(void)context;
	while(1)
	{


	}
}

